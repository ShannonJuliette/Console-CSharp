﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    class DoublyLL
    {
        private Node head;
        private Node tail;

        //The constructor initialises the head and tail to null
        public DoublyLL()
        {
            head = null;
            tail = null;
        }

        //Getters for the class fields head and tail
        public Node GetHead()
        {
            return head;
        }

        public Node GetTail()
        {
            return tail;
        }


        //Setters for the class fields head and tail
        public void SetHead(Node p)
        {
            head = p;
        }

        public void SetTail(Node p)
        {
            tail = p;
        }

        //This method returns the length of the linked list
        //This method loops through the linked list and increments as it goes through the nodes
        public int GetLength()
        {
            if(head == null)
            {
                return 0;
            }
            int len = 0;
            Node p = head;
            //It goes to the next address until the pointer becomes null
            //it means we reached the end of the list
            while(p != null)
            {
                len++;
                p = p.GetNext();
            }
            return (len); 
        }//end of method

        //This method adds the current node to the beginning of the list
        public Node AddToHead(Node p)
        {
            //if list currently empty
            if(head == null)
            {
                head = p;
                tail = p;
            }
            else
            {
                head.SetPrevious(p);
                p.SetNext(head);
                head = p;
            }
            return head;
        }//end of method

        //This method adds the current node to the end of the list
        public Node AddToTail(Node p)
        {
            //if list currently empty
            if(tail == null)
            {
                tail = p;
                head = p;
            }
            else
            {
                tail.SetNext(p);
                p.SetPrevious(tail);
                tail = p;
            }
            return tail;
        }//end of method

        //This method prints the nodes in the linked list in reverse order
        //Starting from the tail
        public void PrintReverse()
        {
            if (head == null)
            {
                Console.WriteLine("List is currently empty");
                return;
            }
            Node p = tail;
            string str = "";
            while (p != null) 
            {
                str += p.GetData() + " ";
                p = p.GetPrevious();
                //The loop will stop when the pointer is null
            } 
            Console.Write(str); 
        }//end of method

        //This method finds the middle node in the linked list
        public Node GetMid()
        {
            if (head == null)
            {
                Console.WriteLine("List is currently empty");
                return null;
            }
            Node p = head;
            int len = 0;
            decimal mid = GetLength() / 2;
            mid = Math.Ceiling(mid); //the next whole integer
            while(len != mid)
            {
                p = p.GetNext();
                len++;
            }
            return p;
        }//end of method

        //This method checks if a number is prime
        static Boolean isPrime(int n)
        {
            Boolean b = true;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                {
                    b = false;
                    break;
                }
            }
            return b;
        }//end of method

        //This method prints 5 prime numbers per line
        public string PrintPrime()
        {
            if (head == null)
            {
                Console.WriteLine("List is currently empty");
                return null;
            }
            Node p = head;
            int counter = 0;
            string str = "";
            while(p != null)
            {
                if (isPrime(p.GetData())){
                    str += p.GetData() + " ";
                    counter++;
                    //as soon as it has five prime numbers
                    //inserts a new line
                    if(counter == 5)
                    {
                        str += "\n";
                        counter = 0;
                    }
                }
                p = p.GetNext();
            }
            return str;
        }//end of method
        
    }
}
