﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Assignment2
{
    class Program
    {

        //This method reads file1 and creates a doubly linked list to store the file content
        static DoublyLL readFile1()
        {
            DoublyLL list1 = new DoublyLL();
            string[] A = File.ReadAllText(@"C:\Users\HP\Desktop\Data Structures Assignment\file1.txt").Split(" ");
            for (int i = 0; i < A.Length; i++)
            {
                Node p = new Node(Int32.Parse(A[i]));
                list1.AddToTail(p);
            }
            return list1;
        }//end of method

        //This method reads file2 and creates a doubly linked list to store the file content
        static DoublyLL readFile2()
        {
            DoublyLL list2 = new DoublyLL();
            string[] A = File.ReadAllText(@"C:\Users\HP\Desktop\Data Structures Assignment\file2.txt").Split(" ");
            for (int i = 0; i < A.Length; i++)
            {
                Node p = new Node(Int32.Parse(A[i]));
                list2.AddToTail(p);
            }
            return list2;
        }//end of method

        //This method reads file3 and creates a doubly linked list to store the file content
        static DoublyLL readFile3()
        {
            DoublyLL list3 = new DoublyLL();
            string[] A = File.ReadAllText(@"C:\Users\HP\Desktop\Data Structures Assignment\file3.txt").Split(" ");
            for (int i = 0; i < A.Length; i++)
            {
                Node p = new Node(Int32.Parse(A[i]));
                list3.AddToTail(p);
            }
            return list3;
        }//end of method


        //This method finds the overlapping elements in two doubly linked lists
        //Runtime for this function will be O(n^2)
        static List<int> FindIntersection(DoublyLL l1, DoublyLL l2, DoublyLL l3)
        {
            Node l1pointer = l1.GetHead();
            Node l2pointer = l2.GetHead();
            List<int> first_intersect = new List<int>();

            //nested loop to find overlapping elements between list1 and list2
            while(l1pointer != null)
            {
                while (l2pointer != null)
                {
                    if (l1pointer.GetData() == l2pointer.GetData())
                    {
                        first_intersect.Add(l1pointer.GetData());
                    }
                    l2pointer = l2pointer.GetNext();
                }
                l2pointer = l2.GetHead();
                l1pointer = l1pointer.GetNext();
            }

            Node l3pointer = l3.GetHead();
            List<int> intersection = new List<int>();
           
            //using the resulting list of common elements from the first two lists
            //now comparing it to the third list
            while (l3pointer != null)
            {
                foreach (int i in first_intersect)
                {
                    if (i == l3pointer.GetData())
                    {
                        intersection.Add(i);
                    }
                }
                l3pointer = l3pointer.GetNext();  
            }
            return intersection;
        }//end of method

        //Start of Main
        static void Main(string[] args)
            {
            //calling the readFile functions to create and store txt file content into doubly linked lists
                DoublyLL list1 = readFile1();
                DoublyLL list2 = readFile2();
                DoublyLL list3 = readFile3();

            //Printing the lists in reverse order
                Console.WriteLine("Printing list1 in reverse order: ");
                list1.PrintReverse();
                Console.WriteLine("\n\nPrinting list2 in reverse order: ");
                list2.PrintReverse();
                Console.WriteLine("\n\nPrinting list3 in reverse order: ");
                list3.PrintReverse();

            //Printing the size of the doubly linked lists
                int list1Length = list1.GetLength();
                int list2Length = list2.GetLength();
                int list3Length = list3.GetLength();

                Console.WriteLine("\n\nLength of list1: " + list1Length);
                Console.WriteLine("Length of list2: " + list2Length);
                Console.WriteLine("Length of list3: " + list3Length);

            //Printing the middle element in each lists
                Console.WriteLine("\nThe middle element in list1 is: " + list1.GetMid().GetData());
                Console.WriteLine("The middle element in list2 is: " + list2.GetMid().GetData());
                Console.WriteLine("The middle element in list3 is: " + list3.GetMid().GetData());

            //Printing the prime numbers in each lists
                Console.WriteLine("\nPrinting the prime numbers in list 1: ");
                string str = list1.PrintPrime();
                Console.WriteLine(str);

                Console.WriteLine("\nPrinting the prime numbers in list 2: ");
                str = list2.PrintPrime();
                Console.WriteLine(str);

                Console.WriteLine("\nPrinting the prime numbers in list 3: ");
                str = list3.PrintPrime();
                Console.WriteLine(str);

            //Printing the intersection between the three lists
                List<int> intersection = FindIntersection(list1, list2, list3);

                Console.WriteLine("\nPrinting the intersection: ");

                foreach (int r in intersection)
                {
                    Console.Write(r + " ");
                }

                Console.WriteLine("\n\nPress any key to continue...");
                Console.ReadKey();
            }//end of Main
        }
    }

