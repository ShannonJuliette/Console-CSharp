﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    class Node
    {
        private int data; //the data held in the list
        private Node next; //pointer to the next item
        private Node previous; //pointer to the previous item

        //The constructor initialises the next and previous pointers
        public Node(int num)
        {
            this.data = num;
            next = null;
            previous = null;
        }

        //Getters for the class fields
        public int GetData()
        {
            return this.data;
        }

        public Node GetNext()
        {
            return this.next;
        }

        public Node GetPrevious()
        {
            return this.previous;
        }

        //Setters for the class fields

        public void SetData(int n)
        {
            this.data = n;
        }

        public void SetNext(Node p)
        {
            this.next = p;
        }

        public void SetPrevious(Node p)
        {
            this.previous = p;
        }

    }
}
