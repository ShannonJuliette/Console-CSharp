﻿using System;
using System.IO;

namespace Assignment1
{
    class Program
    {
        //This method gets the position of the minimum number in the array
        static int getMinPos(int[] A)
        {
            //initialises the value of pos to the first index
            int pos = 0;
            for(int i = 1; i < A.Length; i++)
            //starts looping from the second index
            {
                if (A[i] < A[pos])
                {
                    //if current element is found to be lower than the one stored at position pos
                    //pos takes the value of the current index
                    pos = i;
                }
            }
            return pos;
        }//end of method
        static double getAverage(int[] A)
        {
            int total = 0;
            foreach(int n in A)
            {
                //adding up all the integers in the array
                total += n;
            }
            return (total / A.Length);
            //average is the total sum divided by the number of elements
        }//end of method

        //This method counts the number of even numbers
        static int getEvensCount(int[] A)
        {
            int evensCount = 0;
            foreach(int n in A)
            {
                //if a number is even, when divided by 2, it should not leave a remainder
                if (n % 2 == 0)
                {
                    evensCount++;
                }
            }
            return evensCount;
        }//end of method
        static int getBiggerThanAverageCount(int[] A)
        {
            double average = getAverage(A);
            int count = 0;
            foreach(int n in A)
            {
                //if current element greater than average
                //increment count
                if (n > average)
                {
                    count++;
                }
            }
            return count;
        }//end of method

        //This method checks if all elements in an array are equal
        static Boolean areAllEqual(int[] A)
        {
            int temp = A[0];
            //assigning the first element of the array to the variable temp for comparison
            bool msg = true;
            //stays true until a different number is found in the array
            foreach(int n in A)
            {
                if(temp != n)
                {
                    msg = false;
                    break;
                    //break as soon as a different number is found
                    //no need to loop through the remaining elements
                }
            }
            return msg;
        }//end of method

        //This method checks if all the elements in an array are unique
        static Boolean areAllDiff(int[] A)
        {
            bool msg = true;
            for (int i = 0; i<A.Length; i++)
            {
                for(int j = 0; j<A.Length; j++)
                {
                    if(A[i] == A[j] && i != j)
                    {
                        //if elements overlap at different indexes 
                        //msg turns to false
                        msg = false;
                        break;
                        //break as soon as that is the case
                        //preventing unnecessary looping
                    }
                }
            }
            
            return msg;
        }//end of method

        //This method checks if the array is sorted in ascending order
        static Boolean isArraySorted(int[] A)
        {
            bool sorted = true;
            for(int n = 0; n < A.Length-1; n++)
            {
                if (A[n] > A[n + 1])
                {
                    //as soon as the current element is found to be greater than the next one
                    //variable sorted turns to false and we break out of the array
                    sorted = false;
                    break;
                }
            }
            return sorted;
        }//end of method

        //This method checks if a number is prime
        static Boolean isPrime(int n)
        {
            Boolean b = true;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                {
                    b = false;
                    break;
                }
            }
            return b;
        }//end of method

        //This method calls the method isPrime to check if the current element is prime
        //It then increments the count when that is true
        static int getPrimeCount(int[] A)
        {
            int count = 0;
            foreach(int n in A)
            {
                //0 and 1 as they are not prime numbers despite matching the criteria (only divisible by itself)
                //they need to be excluded
                if (isPrime(n) && (n != 0) && (n != 1))
                {
                    count++;
                }
            }
            return count;
        }//end of method

        //This method reads the text file and creates an array to store the elements
        static int[] readFile()
        {
            string[] A = File.ReadAllText(@"C:\Users\HP\Desktop\Shannon Juliette 19486116 (Assignment 1)\inputassignment1.txt").Split(" ");
            int[] intA = new int[A.Length];
            //Converting all the elements in the string array to integer and storing them in another array 
            for (int i = 0; i < A.Length; i++)
            {
                intA[i] = Int32.Parse(A[i]);
            }
            return intA;
        }//end of method

        static void Main(string[] args)
        {  
            int[] intArray = readFile();

            //Printing all the elements in the array
            foreach (int n in intArray)
            {
                Console.Write(n + " ");
            }

            //Calling the functions and assigning them to variables
            int min = intArray[getMinPos(intArray)]; //using the index to get the minimum number from array
            int minPos = getMinPos(intArray);
            int primeCount = getPrimeCount(intArray);
            double average = getAverage(intArray);
            int evensCount = getEvensCount(intArray);
            //if a number is not an even number, it can only be an odd number
            int oddsCount = intArray.Length - evensCount;
            int greaterAverageCount = getBiggerThanAverageCount(intArray);

            Console.WriteLine("\n\nThe minimum number is: " + min + " at position: " + minPos);
            Console.WriteLine("The number of prime numbers: " + primeCount);
            Console.WriteLine("The average number is: " + average);
            Console.WriteLine("The number of even numbers: " + evensCount);
            Console.WriteLine("The number of odd numbers: " + oddsCount);
            Console.WriteLine("The number of numbers greater than average: " + greaterAverageCount);
            Console.WriteLine("Are all the numbers equal? " + areAllEqual(intArray));
            Console.WriteLine("Are all the numbers different? " + areAllDiff(intArray));
            Console.WriteLine("Is array sorted? " + isArraySorted(intArray));

            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
    }
}
